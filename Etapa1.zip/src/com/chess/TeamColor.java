package com.chess;
/*
    Clasa pentru identificarea culorilor echipelor
 */
public class TeamColor {
    static final int WHITE = 0;
    static final int BLACK = 1;
}