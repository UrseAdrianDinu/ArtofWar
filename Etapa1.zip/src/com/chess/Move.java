package com.chess;
/*
    Clasa pentru identificarea unui tip de mutare
 */
public class Move {
    public static int CAPTURE = 0;
    public static int FREE = 1;
    public static int BLOCK = 2;

}
